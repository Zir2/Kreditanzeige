---
name: Modern Credit Dashboard
colors:
  surface: '#fdf7ff'
  surface-dim: '#ded8e0'
  surface-bright: '#fdf7ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f2fa'
  surface-container: '#f2ecf4'
  surface-container-high: '#ece6ee'
  surface-container-highest: '#e6e0e9'
  on-surface: '#1d1b20'
  on-surface-variant: '#494551'
  inverse-surface: '#322f35'
  inverse-on-surface: '#f5eff7'
  outline: '#7a7582'
  outline-variant: '#cbc4d2'
  surface-tint: '#6750a4'
  primary: '#4f378a'
  on-primary: '#ffffff'
  primary-container: '#6750a4'
  on-primary-container: '#e0d2ff'
  inverse-primary: '#cfbcff'
  secondary: '#63597c'
  on-secondary: '#ffffff'
  secondary-container: '#e1d4fd'
  on-secondary-container: '#645a7d'
  tertiary: '#765b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#c9a74d'
  on-tertiary-container: '#503d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#cfbcff'
  on-primary-fixed: '#22005d'
  on-primary-fixed-variant: '#4f378a'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#cdc0e9'
  on-secondary-fixed: '#1f1635'
  on-secondary-fixed-variant: '#4b4263'
  tertiary-fixed: '#ffdf93'
  tertiary-fixed-dim: '#e7c365'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#594400'
  background: '#fdf7ff'
  on-background: '#1d1b20'
  surface-variant: '#e6e0e9'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  container-max: 1280px
---

## Brand & Style
The design system is engineered for the 2026 financial landscape, prioritizing hyper-clarity and a "breathable" high-tech aesthetic. It employs a **Glassmorphic Minimalism** style—fusing the cleanliness of Swiss design with the depth of layered, translucent interfaces. 

The emotional goal is to transform the anxiety of debt management into a sense of controlled, futuristic empowerment. The UI utilizes expansive whitespace, subtle kinetic motion, and light-refracting surfaces to suggest transparency and precision. The target audience is the modern, tech-literate user who demands financial tools that feel as sophisticated as their hardware.

## Colors
The palette is functional and semantic, using color as the primary vehicle for information hierarchy. 

- **Primary Red (#F43F5E):** Reserved exclusively for liabilities and debt amounts. It is high-chroma to ensure visibility but balanced by the airy background.
- **Primary Green (#10B981):** Represents achievement and settled payments. Used for positive balances and "completed" states.
- **Primary Orange (#F59E0B):** Signifies anticipation. It highlights upcoming or pending actions without the urgency of red.
- **Neutral Palette:** The background is a composite of ultra-light grays and pure white, often applied with 70-80% opacity to enable glass effects. Text utilizes a deep charcoal (#0F172A) for maximum legibility against translucent layers.

## Typography
The typography system uses a tri-font approach to differentiate between brand presence, readability, and technical data. 

- **Hanken Grotesk** is used for headlines to provide a sharp, contemporary character.
- **Inter** handles all body copy, ensuring high legibility even at reduced sizes within glass containers.
- **Geist** is reserved for labels and financial data (numbers/monetary amounts), providing a monospaced, technical feel that aligns with the "high-tech" brand promise. 

Hierarchy is established through weight and letter-spacing rather than just size, maintaining a sophisticated, editorial look.

## Layout & Spacing
This design system utilizes a **Fluid 12-Column Grid** with a "Fixed Center" container for desktop views. 

The spacing rhythm is based on an 8px square grid, but the layout philosophy is "Airy." This means margins are intentionally wide to prevent the glass surfaces from feeling cluttered. 

- **Mobile:** Single column with 16px side margins. Cards span the full width.
- **Tablet:** 6-column layout with 24px gutters.
- **Desktop:** 12-column layout with 24px gutters and 40px external margins. 

Elements are grouped in "Glass Modules" which use internal padding of 24px or 32px to ensure content never touches the edges of the translucent containers.

## Elevation & Depth
Depth is the cornerstone of this design system. We move away from traditional shadows in favor of **Layered Glassmorphism**:

1.  **Backdrop Blur:** Every primary container uses a `backdrop-filter: blur(20px)`. This separates the content from the background gradients.
2.  **Inner Glow:** Containers feature a 1px white border with 20% opacity on the top and left sides to simulate a light source hitting the "glass" edge.
3.  **Soft Shadows:** When an element is raised (e.g., a hovering card), use a very large, ultra-low opacity shadow (Color: `rgba(15, 23, 42, 0.05)`, Blur: `40px`) to suggest floating rather than physical weight.
4.  **Tinted Overlays:** In dark mode or high-contrast scenarios, the glass surfaces are tinted with a 2% saturation of the primary brand colors to create environmental cohesion.

## Shapes
The shape language is "Optimistically Geometric." We use **Rounded (Level 2)** settings for most components to maintain a friendly, modern feel while preserving a sense of structure.

- **Primary Cards:** 1rem (16px) corner radius.
- **Buttons and Inputs:** 0.5rem (8px) corner radius.
- **Status Pills:** Fully rounded (pill-shaped) to distinguish them from interactive buttons.

This consistent rounding helps soften the high-tech edge of the glass effects, making the finance dashboard feel approachable.

## Components

### Glass Cards
The primary container for all data. Must feature a subtle `linear-gradient(135deg, rgba(255,255,255,0.4), rgba(255,255,255,0.1))` and the standard 20px backdrop blur.

### Status Indicators
- **Liabilities:** A "Ghost Red" pill with a solid 2px left-border and light red background tint.
- **Upcoming:** A "Glowing Orange" indicator using a small 8px dot with a subtle outer glow.

### Interactive Elements
- **Buttons:** Primary buttons use a solid, high-contrast background (Neutral Dark) to provide a "grounding" element against the glass UI.
- **Input Fields:** Semi-transparent backgrounds (`rgba(255,255,255,0.5)`) with a 1px solid border that brightens on focus.

### Credit Score Radial
A bespoke component featuring a dual-track gradient. The active track uses a gradient of the primary colors (Red to Green) to visually represent the user's journey from debt to financial health.

### Lists
Unstyled lists are avoided. All list items are contained within soft-bordered rows with 12px of vertical padding, separated by high-transparency horizontal rules.